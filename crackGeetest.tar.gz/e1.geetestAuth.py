
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains as AC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from time import sleep
from PIL import Image
from io import BytesIO
import numpy as np

class CrackGeetest:
    def __init__(self, user=None, passwd=None ):
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.url = 'https://auth.geetest.com/login/'
        self.user = user
        self.passwd = passwd
        self.wait = WebDriverWait(self.driver, 10)
        self.js = 'var q = document.getElementsByTagName("canvas"); q[{number}].setAttribute("style", "opacity: 1;display: block");'
    def open(self):
        # 打开目标网页   '1','1',
        self.driver.get(self.url)
        user = self.wait.until(EC.presence_of_element_located((By.XPATH, '//input[@type="email"]')))
        sleep(1)
        passwd = self.wait.until(EC.presence_of_element_located((By.XPATH, '//input[@type="password"]')))
        sleep(1)
        user.send_keys(self.user)
        passwd.send_keys(self.passwd)

    def getBtn(self):
        # 并点击，出现图片
        btn = self.wait.until(EC.element_to_be_clickable((By.XPATH, '//div[@class="geetest_radar_tip"]')))
        btn.click()

    def getSlider(self):
        # 获取滑块
        slider = self.wait.until(EC.element_to_be_clickable((By.XPATH, '//div[@class="geetest_slider_button"]')))
        print('getSlider', slider)
        return slider

    def crack(self):
        # 主进口
        self.open()
        self.getBtn()
        # number = 0: display full backgroud with mask
        # number = 1: display slice
        #  number = 2. display full Backgroud
        fullImg = self.getImg(2)
        fullImg.save('fullImg.png')
        sliceImg = self.getImg(1)
        sliceImg.save('sliceImg.png')
        fadeImg = self.getImg(0)
        fadeImg.save('fadeImg.png')

        self.showAll()
        sleep(.5)
        slider = self.getSlider()
        print(slider)
        x, y = self.getGap(fadeImg, fullImg)
        print('x = %s, y = %s'%(x,y))
        # 小滑块距离边缘6 px
        # x = (x-6)*50/260
        track = self.getTrack(x)

        self.simuMove(slider, track)

    def finishi(self):
        self.driver.close()

    def getPosition(self):
        # 获取图片位置
        img = self.wait.until(EC.presence_of_element_located((By.TAG_NAME, 'canvas')))
        sleep(.5)
        size = img.size
        location = img.location
        left = location.get('x')
        top = location.get('y')
        right = location.get('x') + size.get('width')
        bottom = location.get('y') + size.get('height')
        return (left, top, right, bottom)

    def success(self):
        sleep(1)
        # EC.presence_of_element_located((By.XPATH, '//')


    def getImg(self, number):
        # js = [
        #     'var q = document.getElementsByTagName("canvas"); q[0].setAttribute("style", "display: block");',
        #     'var q = document.getElementsByTagName("canvas"); q[1].setAttribute("style", "display: block");',
        #     'var q = document.getElementsByTagName("canvas"); q[2].setAttribute("style", "display: block");'
        #     ]
        # jsHide: all pic hide
        js = self.js.format(number = number)
        print(js)
        jsHide = 'var q = document.getElementsByTagName("canvas"); for(var i=0;i<q.length;i++) {q[i].setAttribute("style", "display: none");}'
        # save pictures
        self.driver.execute_script(jsHide)
        sleep(1)
        self.driver.execute_script(js)
        sleep(1)
        img = self.driver.get_screenshot_as_png()
        img = Image.open(BytesIO(img))
        left, top, right, bottom = self.getPosition()
        print(left, top, right, bottom)
        return img.crop((left, top, right, bottom))

    def showAll(self):
        self.driver.execute_script(self.js.format(number = 0))
        self.driver.execute_script(self.js.format(number = 1))



    def getGap(self, img1, img2):
        # 获取缺口位图
        width, height = img1.size
        print(width, height)
        img1 = img1.load()
        img2 = img2.load()
        threshold = 64
        for i in range(width):
            for j in range(height):
                if abs(img1[i, j][1] - img2[i, j][1]) > threshold and abs(img1[i, j][2] - img2[i, j][2]) > threshold and abs(img1[i, j][2] - img2[i, j][2]) > threshold:
                    return (i, j)
        return (0, 0)

    def simuMove(self, slider, track):
        act = AC(self.driver)
        onElem = act.click_and_hold(slider).perform()
        for x in track:
            print(x)
            act.move_by_offset(x, 0).perform()
            act = AC(self.driver)
            sleep(.02)
        sleep(.5)
        act.release().perform()

    def getTrack(self, distance):
        print('independent getTrack')
        a1 = .25 + np.random.random() * .25
        a2 = .5 + np.random.random() * .25
        a3 = 1 - a1 - a2
        print(a1, a2, a3, sum([a1, a2, a3]))
        n1 = np.random.randint(5, 10)
        n2 = np.random.randint(10, 15)
        n3 = np.random.randint(4, 8)
        alpha = np.linspace(-np.pi / 2, np.pi / 2, n1)
        beta = np.linspace(-np.pi / 2, np.pi / 2, n2)
        gama = np.linspace(-np.pi / 2, np.pi / 2, n3)
        y1 = np.round(np.cos(alpha), 3)
        y2 = np.round(np.cos(beta), 3)
        y3 = np.round(np.cos(gama), 3)
        print(y1, y2, y3, sep='\n')
        print('*-' * 30)
        y1 = np.round(a1 * y1 / np.sum(y1), 3)
        y2 = np.round(a2 * y2 / np.sum(y2), 3)
        y3 = np.round(a3 * y3 / np.sum(y3), 3)
        print(y1, y2, y3, sep='\n')
        print('*=' * 30)
        y = np.hstack([y1, y2, y3])
        print(np.sum(y))
        y = np.round(y * distance, 3)
        return y

if __name__ == '__main__':
    user = '1340714544@qq.com'
    passwd = 'sadfipqweir90124'
    crack = CrackGeetest(user, passwd)
    crack.crack()
    sleep(10)
    crack.finishi()








